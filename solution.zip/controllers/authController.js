// authController.js
const { users } = require('../models/userModel');

const loginUser = (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (user) {
    res.cookie('userCookie', username, {
      httpOnly: true,
      maxAge: 60000 // 60 seconds
    });
    res.redirect('/');
  } else {
    res.redirect('/login?error=1');
  }
};

module.exports = {
  loginUser
};
