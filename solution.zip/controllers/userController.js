const { User, users } = require('../models/userModel');

// Fetch all users
function getAllUsers() {
  return users;
}

// Fetch specific user by ID
function getUserById(id) {
  return users.find(user => user.id === id);
}

// Create a new user
function createUser(username, password) {
  const userId = users.length + 1;
  const user = new User(userId, username, password);
  users.push(user);
  return user;
}

// Update user
function updateUser(id, username, password) {
  const user = users.find(user => user.id === id);
  if (user) {
    user.username = username;
    user.password = password;
  }
  return user;
}

// Delete user
function deleteUser(id) {
  const userIndex = users.findIndex(user => user.id === id);
  if (userIndex !== -1) {
    users.splice(userIndex, 1);
    return true;
  }
  return false;
}

module.exports = {
  getAllUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser
};
