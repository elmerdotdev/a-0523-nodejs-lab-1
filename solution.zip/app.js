const express = require('express')
const app = express()
const cookieParser = require('cookie-parser')
const PORT = 3001

const userRouter = require('./routes/userRoutes')
const authController = require('./controllers/authController');

app.use(express.urlencoded({ extended: true }))
app.use(express.json())

app.set('view engine', 'ejs')

// Secret Key
const secretKey = 'vihori3ljvk09nlkc2wwgr1z'

// Parse cookies object
app.use(cookieParser(secretKey))

app.get('/', (req, res) => {
  if (req.cookies && req.cookies.userCookie) {
    res.render('index', { pageTitle: 'Home', username: req.cookies.userCookie })
  } else {
    res.redirect('/login')
  }
})

// Route to login
app.get('/login', (req, res) => {
  const { error, logout } = req.query
  if (req.cookies && req.cookies.userCookie) {
    res.redirect('/')
  } else {
    res.render('login', { pageTitle: 'Login', error, logout })
  }
})

// Route to post request
app.post('/login', authController.loginUser);

// Route to log out
app.get('/logout', (req, res) => {
  res.clearCookie('userCookie')
  res.redirect('/login?logout=success')
})


app.use('/users', userRouter)

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}...`)
})