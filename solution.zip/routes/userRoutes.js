const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController'); // Updated to userController

// Route to fetch all users
router.get('/', (req, res) => {
  const users = userController.getAllUsers(); // Updated to getAllUsers
  // res.render('users', { users, pageTitle: 'Users List' }); // Updated view and data
  res.json(users)
});

// Route to fetch one user
router.get('/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  const user = userController.getUserById(userId); // Updated to getUserById
  if (!user) {
    res.status(404).json({ error: 'No user found' }); // Updated error message
  } else {
    res.status(200).json(user);
  }
});

// Route to add a user
router.post('/', (req, res) => {
  const { username, password } = req.body; // Updated to name and password
  const user = userController.createUser(username, password); // Updated to createUser
  res.status(201).json(user);
});

// Route to update user
router.put('/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  const { username, password } = req.body; // Updated to name and password
  const user = userController.updateUser(userId, username, password); // Updated to updateUser
  if (!user) {
    res.status(404).json({ error: 'User does not exist' }); // Updated error message
  } else {
    res.status(200).json(user);
  }
});

// Route to delete user
router.delete('/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  const result = userController.deleteUser(userId); // Updated to deleteUser
  if (result) {
    res.status(200).send('User deleted!'); // Updated confirmation message
  } else {
    res.status(404).json({ error: 'User does not exist' }); // Updated error message
  }
});

module.exports = router;
